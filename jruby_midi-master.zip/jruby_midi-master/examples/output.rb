dir = File.dirname(File.expand_path(__FILE__))
$LOAD_PATH.unshift dir + '/../lib'

require 'midi-jruby'

# this program selects the first midi output and sends some arpeggiated chords to it

output = MIDIJRuby::Output.first
#notes = [36, 38, 40, 42, 44, 46, 37, 39, 41, 43, 45, 47]
#notes = [36, 40, 43] # C E G
notes = [43, 40, 36] # G E C
octaves = 5
duration = 0.1

# MIDIJRuby::Device.all.to_s will list your midi devices

output.open do |output|
  loop do
  
    (0..((octaves-1)*12)).step(12) do |oct|

      notes.each do |note|
    	
        output.puts(0x90, note + oct, 100) # note on
        sleep(duration)				             # wait
        output.puts(0x80, note + oct, 100) # note off
      
      end    
    end
    
    (0..((octaves-1)/12)).step(12) do |oct|
      notes.each do |note|
        output.puts(0x90, note + oct, 100) # note on
        sleep(duration)				             # wait
        output.puts(0x80, note + oct, 100) # note off
      end
    end    
  end  
end
