module MIDI

    VERSION_MAJOR = 1
    VERSION_MINOR = 0
    VERSION_TWEAK = 0
    Version = "#{VERSION_MAJOR}.#{VERSION_MINOR}.#{VERSION_TWEAK}"
    Copyright = 'Copyright (c) 2003-2007 by Jim Menard <jimm@io.com>'

end
