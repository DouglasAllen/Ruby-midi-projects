require 'midilib/utils'
puts note_to_s(0)